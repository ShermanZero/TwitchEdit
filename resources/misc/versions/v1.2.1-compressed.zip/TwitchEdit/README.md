# TwitchEdit
### v1.2

![TwitchEdit](resources/popup.jpg)

After getting tired of spending the extra 10 seconds to navigate to my clip page directly, and then modify the URL by typing /edit at the end of it, I decided to write this little Chrome Extension which automates that process for you.  Once installed, any time you visit your clips page and click on a clip, you will see a brand new "Edit" icon which will take you directly to the clip in a **NEW TAB** (thank God) and allow you to edit it.

**Please note that this will not work if you have already edited your clip, or if it has been published for more than 24 hours**

[Get it on the Chrome Web Store](https://chrome.google.com/webstore/detail/dechjnpdlchkchhgjnakdifhkdlhloob/publish-accepted?authuser=0&hl=en)

If you appreciate what I've done, please feel free to head over to my [Twitch channel](https://twitch.tv/ShermanZero) and drop a follow to show your support and appreciation!  I play a lot of Overwatch, and promote PMA!

# Changelog

**v1.2 (08/15/19)**
- Fixed bug which prevented the extension from working on some channels

**v1.1 (08/14/19)**
- Overhaul to the UI, made it look like it's part of Twitch
- Added more comments and console.log() commands
- Create a popup.html page which displays info about the extension
- Took different screenshots

**v1.0 (08/13/19)**
- *Initial commit*

*This is technically open-source since I have made the code publicly available here to you all.  I could have simply created a repository with just a README, but decided to let you guys see what I've done.  You are welcome to clone, fork, download, or whatever this project for yourself, all I ask is that you leave my credits in the files wherever they appear.*
